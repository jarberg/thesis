This is a Win32 version of the GLE library
compiled as a shared library (DLL) for use with
e.g. Python's ctypes foreign-function interface.

To install, copy the file gle32.dll to your system32
directory.